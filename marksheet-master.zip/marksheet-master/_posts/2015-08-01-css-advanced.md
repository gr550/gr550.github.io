---
layout: chapter
title: "Advanced CSS"
subtitle: "From layout to life"
section: css
---

For a while, CSS has remained **one-sided**: one color, one state, one instant, one device.

Throughout the years, it has developed new features that alter interactions, intermediate states, and even time.
