---
layout: chapter
title: "Introduction"
subtitle: "An overview of how the <strong>Web</strong> works"
section: web
---

Before diving into the technical and practical aspect of coding, you need to have a **basic** understanding of how the underlying _environment_ works.

This introduction is meant to provide a quick overview of both the **Internet** and the **Web**.
