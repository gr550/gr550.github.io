---
layout: chapter
title: "HTML <strong>Content</strong>"
subtitle: "What the <strong>Web</strong> is all about"
section: html
---

The **Web** was created to share _documents_ via Internet, and **HTML** is the _language_ in which these documents are written.

While **text** has always been the primary medium, HTML evolved to incorporate other types of content like **images** and **videos**.